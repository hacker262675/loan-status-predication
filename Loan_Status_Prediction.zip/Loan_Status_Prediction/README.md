Loan-Status-Prediction
Contains three parts of Project.
1.Training.
contains the model building code and Training the model.We convert this file to pickle to deploy the model.
2.DataSet
3.Templates and .py file.
.py file is used to connect template(html) files and pickle file and after integrating we run our app.
